Fancy Tavern is a game ready package with beautiful hand painted textures.

In this package you will find:

-Tavern,1168 tris;
-Additional objects(barrel,haystack,trough,chimney),508 tris;
-High quality 2048x2048 textures in TIF format(easy to downsize);

All models are in FBX format.