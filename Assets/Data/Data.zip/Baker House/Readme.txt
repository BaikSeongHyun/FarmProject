Baker House

The part of Lowpoly Township Set

https://www.assetstore.unity3d.com/en/#!/content/22258

House - 1025 tris

Barrel - 276 tris

This modelsare in FBX, have hand pained trxtures in TIFF